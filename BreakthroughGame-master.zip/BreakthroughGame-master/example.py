import pygame.examples.aliens as game
 
if __name__ == '__main__':
    game.main() 

